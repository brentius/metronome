Tests live in code/tests in the project repository.
