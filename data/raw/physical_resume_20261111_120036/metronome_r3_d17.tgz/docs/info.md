## How it works

See wiki/ARCHITECTURE.md and wiki/SPEC.md in the project repository.

## How to test

Load a program over the host SPI pins (wiki/TOOLCHAIN.md).
